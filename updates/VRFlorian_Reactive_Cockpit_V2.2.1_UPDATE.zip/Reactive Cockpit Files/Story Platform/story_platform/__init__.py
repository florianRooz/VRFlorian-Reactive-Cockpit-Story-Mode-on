"""Reactive Cockpit Story Platform graph-native runtime."""

VERSION = "0.12.3-ALTITUDE-EXIT-HARDENING"
