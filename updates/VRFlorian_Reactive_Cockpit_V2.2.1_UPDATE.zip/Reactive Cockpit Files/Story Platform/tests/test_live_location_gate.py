from __future__ import annotations

import unittest

from story_platform.environments import EnvironmentRuntime
from story_platform.telemetry import WorldModel, is_live_location_event
from story_platform.runner import live_location_confirmation_source


class LiveLocationGateTests(unittest.TestCase):
    def test_absolute_location_events_with_a_system_open_the_gate(self) -> None:
        for name in ("Location", "FSDJump", "CarrierJump"):
            with self.subTest(name=name):
                self.assertTrue(is_live_location_event({"event": name, "StarSystem": "Sol"}))

    def test_menu_and_status_activity_do_not_open_the_gate(self) -> None:
        for event in (
            {"event": "Music", "MusicTrack": "MainMenu"},
            {"event": "LoadGame"},
            {"event": "Loadout", "StarSystem": "Sol"},
            {"timestamp": "2026-09-15T17:00:00Z", "BodyName": "Earth"},
        ):
            with self.subTest(event=event):
                self.assertFalse(is_live_location_event(event))

    def test_location_without_a_system_does_not_open_the_gate(self) -> None:
        self.assertFalse(is_live_location_event({"event": "Location"}))
        self.assertFalse(is_live_location_event({"event": "FSDJump", "StarSystem": "   "}))

    def test_runtime_accepts_only_a_live_journal_location(self) -> None:
        cached_sol = {"location": {"system": "Sol"}}
        fresh_status = {"timestamp": "2026-09-15T17:00:00Z", "BodyName": "Earth"}

        self.assertIsNone(live_location_confirmation_source("status", fresh_status))
        self.assertIsNone(live_location_confirmation_source("world", cached_sol))
        self.assertIsNone(
            live_location_confirmation_source(
                "journal", {"event": "Music", "MusicTrack": "MainMenu"}
            )
        )
        self.assertEqual(
            live_location_confirmation_source(
                "journal", {"event": "Location", "StarSystem": "Sol"}
            ),
            "journal.Location",
        )

    def test_surface_coordinates_are_cleared_when_ship_loses_planetary_fix(self) -> None:
        world = WorldModel()
        surface = {
            "timestamp": "2026-09-19T12:00:00Z",
            "Flags": (1 << 21) | (1 << 24),
            "BodyName": "Aiabiko 9 a",
            "Latitude": 1.0,
            "Longitude": 2.0,
            "Altitude": 90000.0,
            "Heading": 180.0,
        }
        space = {
            "timestamp": "2026-09-19T12:00:01Z",
            "Flags": (1 << 24),
            "BodyName": "Aiabiko 9 a",
        }

        world.status_signals(surface, None)
        self.assertEqual(world.data["location"]["altitude"], 90000.0)
        world.status_signals(space, surface)

        for key in ("latitude", "longitude", "altitude", "heading"):
            self.assertNotIn(key, world.data["location"])
        self.assertIsNone(world.data["location_updated_at"])

    def test_lost_ship_surface_fix_exits_altitude_bounded_environment(self) -> None:
        rule = {"max_altitude_m": 100000.0}
        ship_in_space = {
            "vehicle": "ship",
            "flags": {"has_lat_long": False},
            "location": {"system": "Aiabiko", "body": "Aiabiko 9 a"},
        }
        on_foot_without_altitude = {
            "vehicle": "on_foot",
            "flags": {"has_lat_long": True},
            "location": {"system": "Aiabiko", "body": "Aiabiko 9 a"},
        }

        self.assertEqual(
            EnvironmentRuntime._altitude_inside(rule, ship_in_space),
            (False, True),
        )
        self.assertEqual(
            EnvironmentRuntime._altitude_inside(rule, on_foot_without_altitude),
            (True, False),
        )


if __name__ == "__main__":
    unittest.main()
