"""Reactive Cockpit Story Platform graph-native runtime."""

VERSION = "0.12.4-LIVE-TELEMETRY-GATE-RECOVERY"
