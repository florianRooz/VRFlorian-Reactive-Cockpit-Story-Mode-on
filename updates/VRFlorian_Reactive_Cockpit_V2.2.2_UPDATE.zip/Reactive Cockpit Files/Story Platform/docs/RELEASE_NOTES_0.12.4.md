# Story Platform 0.12.4 — live telemetry gate recovery

This update repairs the startup safety gate when Story Platform is restarted
while Elite Dangerous is already in a live session.

## Changed

- Fresh gameplay Journal records can release the gate; it is no longer limited
  to `Location`, `FSDJump`, and `CarrierJump`.
- A meaningful change after the initial `Status.json` baseline can also release
  the gate.
- The event that releases the gate is dispatched only after the runtime starts,
  preserving triggers such as `journal.StartJump`.
- Journal tailing is armed before historical world hydration, preventing cached
  records from being mistaken for fresh telemetry.

## Still blocked

- Cached Journal and Status data
- First/baseline Status snapshots
- Timestamp-only Status rewrites
- Main-menu music and Journal lifecycle records

The update does not alter mission graphs, story assets, progress, runtime state,
or player configuration.
